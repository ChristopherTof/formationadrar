************************************
************************************
***************LE SITE**************
************************************
************************************

Les pages qui ont été faites sont : 
- Index
- Musiques
- Boutique
- Produit
- Panier
- Contact
- Newsletter


En ce qui concerne les pages Boutique, Produit, Panier, un bouton panier a été rajouté au menu.

La page Newsletter est accessible via la page contact.



**************************************
**************************************
*************INTERVENANT**************
**************************************
**************************************

Laurie B : Contact et Newletter
Theo : Index
Farid : Musiques
Christopher :  Boutique, Produit, Panier