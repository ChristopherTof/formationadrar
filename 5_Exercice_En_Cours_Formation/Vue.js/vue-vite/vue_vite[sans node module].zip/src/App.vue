<script setup>
import Header from './components/Header.vue';
</script>
<template>
  <Header></Header>
  <router-view></router-view>
</template>

<style scoped></style>
