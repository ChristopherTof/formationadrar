USE test;
-- test des droits affectés
SELECT * FROM utilisateur;
SELECT * FROM article;
SELECT * FROM commentaire;
SELECT * FROM ajouter;
INSERT INTO utilisateur(nom_utilisateur, prenom_utilisateur) VALUE('Mithridate2', 'Mathieu2');
INSERT INTO article (titre_article, contenu_article, date_article, id_utilisateur) VALUE 
('insert article', 'sqiojfiksjqfpjijf', '2024-02-20', 2);
INSERT INTO commentaire(texte_commentaire, date_commentaire, id_utilisateur) VALUE 
('shufyoqslkfjjfg', '2024-02-20 14:20:00', 1);
INSERT INTO ajouter(id_article, id_commentaire) VALUE (1,1);
SELECT titre_article, contenu_article, date_article, nom_utilisateur, prenom_utilisateur
FROM article INNER JOIN utilisateur ON article.id_utilisateur = utilisateur.id_utilisateur;
UPDATE utilisateur SET nom_utilisateur = 'nouveau nom' WHERE id_utilisateur = 1;

-- test des droits non autorisés

DELETE FROM article;
DELETE FROM utilisateur WHERE id_utilisateur = 1;
DELETE FROM commentaire WHERE id_commentaire = 1;
DELETE FROM ajouter WHERE id_article = 1;
