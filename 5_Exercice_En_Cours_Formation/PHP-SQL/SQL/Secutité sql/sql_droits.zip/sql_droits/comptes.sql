-- création des comptes
CREATE USER 'visiteur'@'%' IDENTIFIED BY 'AZERTYui1234';
GRANT SELECT ON test . * TO 'visiteur'@'%';
GRANT INSERT ON test . utilisateur TO 'visiteur'@'%';

CREATE USER 'utilisateur'@'%' IDENTIFIED BY 'AZERTYui1234';
GRANT SELECT, INSERT ON test . * TO 'utilisateur'@'%';
GRANT UPDATE ON test . utilisateur TO  'utilisateur'@'%';
GRANT UPDATE ON test . article TO  'utilisateur'@'%';
GRANT UPDATE ON test . commentaire TO  'utilisateur'@'%';

CREATE USER 'administrateur'@'%' IDENTIFIED BY 'AZERTYui1234';
GRANT SELECT, INSERT, DELETE ON test . * TO 'administrateur'@'%';
GRANT UPDATE ON test . utilisateur TO  'administrateur'@'%';
GRANT UPDATE ON test . article TO  'administrateur'@'%';
GRANT UPDATE ON test . commentaire TO  'administrateur'@'%';

FLUSH PRIVILEGES;

SELECT * FROM mysql.user;