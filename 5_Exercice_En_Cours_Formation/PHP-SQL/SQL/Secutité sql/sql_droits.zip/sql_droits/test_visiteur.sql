-- test des droits affectés

USE test;
SELECT * FROM utilisateur;
SELECT * FROM article;
SELECT * FROM commentaire;
SELECT * FROM ajouter;
INSERT INTO utilisateur(nom_utilisateur, prenom_utilisateur) VALUE('Mithridate', 'Mathieu');

-- test des droits non autorisés
UPDATE utilisateur SET nom_utilisateur = "nouveau nom";
DELETE FROM utilisateur;
INSERT INTO article(titre_article, contenu_article, date_article, id_utilisateur) VALUE 
('Titre de l\'article', 'sjhoifklsqnqjfjsqkjlfljm', '2024-02-20', 1);
INSERT INTO commentaire (texte_commentaire, date_commentaire, id_utilisateur) VALUE 
('jhfsioqfqsdjfjpf', '2024-02-20 14:13:00', 1);