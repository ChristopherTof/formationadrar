-- Création de la base
CREATE DATABASE test;
USE test;

-- Création des tables
CREATE TABLE utilisateur(
id_utilisateur INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
nom_utilisateur VARCHAR(50) NOT NULL,
prenom_utilisateur VARCHAR(50) NOT NULL
)Engine=InnoDB;

CREATE TABLE article(
id_article INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
titre_article VARCHAR(50) NOT NULL,
contenu_article TEXT NOT NULL,
date_article DATE NOT NULL,
id_utilisateur INT NOT NULL
)Engine=InnoDB;

CREATE TABLE commentaire(
id_commentaire INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
texte_commentaire VARCHAR(255) NOT NULL,
date_commentaire DATETIME NOT NULL,
id_utilisateur INT NOT NULL
)Engine=InnoDB;

CREATE TABLE ajouter(
id_commentaire INT NOT NULL,
id_article INT NOT NULL,
PRIMARY KEY(id_commentaire, id_article)
)Engine=InnoDB;

-- Ajout des containtes
ALTER TABLE article
ADD CONSTRAINT fk_rediger_utilisateur
FOREIGN KEY(id_utilisateur)
REFERENCES utilisateur(id_utilisateur);

ALTER TABLE commentaire
ADD CONSTRAINT fk_ecrire_utilisateur
FOREIGN KEY(id_utilisateur)
REFERENCES utilisateur(id_utilisateur);

ALTER TABLE ajouter
ADD CONSTRAINT fk_ajouter_commentaire
FOREIGN KEY(id_commentaire)
REFERENCES commentaire(id_commentaire);

ALTER TABLE ajouter
ADD CONSTRAINT fk_ajouter_article
FOREIGN KEY(id_article)
REFERENCES article(id_article);